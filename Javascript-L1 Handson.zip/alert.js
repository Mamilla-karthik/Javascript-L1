function msg(){
alert("hello user");
}
